#
# VDI.ps1
#
configuration VDI 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
       
        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

	   	[String[]]$Packages=@(),

	    [Hashtable[]]$PublishedApplications = @(),

	    [String]$StoreFrontUrl=$null,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

        [Parameter(Mandatory)]
        [String]$GatewayFQDN,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, CitrixXenDesktopAutomation, CitrixMarketplace, xNetworking

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $gracePath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod"

	$zoneMapPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains\*.$DomainName"
	$zoneMapName = "https"
	$zoneMapValue = 2

	$zoneSecurityPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\2"
	$zoneSecurityName = "1A00"
	$zoneSecurityValue = 0

	$dazzleKey = "HKEY_LOCAL_MACHINE\Software\Wow6432Node\Citrix\Dazzle"
	$selfServiceName = "SelfServiceMode"
	$selfServiceValue = "true"
	$desktopName = "PutShortcutsOnDesktop"
	$desktopValue = "true"
	$startName = "PutShortcutsInStartMenu"
	$startValue = "true"

    $studioMsc = "C:\Program Files\Citrix\Desktop Studio\Studio.msc"

	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

	    xDnsServerAddress DnsServerAddress
        {
            Address        = $DomainControllerIp
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

        Citrix_XenDesktopVDI VDICatalog
        {
            XenDesktopController = $DeliveryController
            CatalogName = "Administrative Desktop"
            DeliveryGroupName = "Administrative Desktop"
            PSDscRunAsCredential = $DomainCreds
            Users = @($DomainCreds.UserName)
            PublishedApplications = $PublishedApplications
			StoreFrontUrl = $StoreFrontUrl
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

		Citrix_XenDesktopStudioController StudioSetup
        {
			XenDesktopController = $DeliveryController
			StudioMsc = $studioMsc
            DependsOn = "[Citrix_XenDesktopVDI]VDICatalog" 
        }

		Citrix_MarketplaceStatus Status
        {
            DeploymentFQDN = $DeploymentFQDN
            GatewayFQDN = $GatewayFQDN
			MachineName = $env:COMPUTERNAME
			Status = "Succeeded"
            DependsOn = "[Citrix_XenDesktopStudioController]StudioSetup" 
        }
    }
} 
