#
# VDI.ps1
#
configuration VDI 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
       
        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

	   	[String[]]$Packages=@(),

	    [Hashtable[]]$PublishedApplications = @(),

	    [String]$StoreFrontUrl=$null,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

        [Parameter(Mandatory)]
        [String]$GatewayFQDN,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
	Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, CitrixXenDesktopAutomation, CitrixMarketplace, xNetworking

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $gracePath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod"

	$zoneMapPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains\*.$DomainName"
	$zoneMapName = "https"
	$zoneMapValue = 2

	$zoneSecurityPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\2"
	$zoneSecurityName = "1A00"
	$zoneSecurityValue = 0

	$dazzleKey = "HKEY_LOCAL_MACHINE\Software\Wow6432Node\Citrix\Dazzle"
	$selfServiceName = "SelfServiceMode"
	$selfServiceValue = "true"
	$desktopName = "PutShortcutsOnDesktop"
	$desktopValue = "true"
	$startName = "PutShortcutsInStartMenu"
	$startValue = "true"

    $studioMsc = "C:\Program Files\Citrix\Desktop Studio\Studio.msc"

	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        Registry ListOfDDC
        {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\Software\Citrix\VirtualDesktopAgent"
            ValueName = "ListOfDDCs"
            ValueData = $DeliveryController
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        Registry SetSelfService
        {
            Ensure = "Present"
            Key = $dazzleKey
            ValueName = $selfServiceName
			ValueType = "String"
            ValueData = $selfServiceValue
            DependsOn = "[Registry]ListOfDDC" 
        }

        Registry SetDesktopShortcuts
        {
            Ensure = "Present"
            Key = $dazzleKey
            ValueName = $desktopName
			ValueType = "String"
            ValueData = $desktopValue
            DependsOn = "[Registry]SetSelfService" 
        }
        
		Registry SetStartShortcuts
        {
            Ensure = "Present"
            Key = $dazzleKey
            ValueName = $startName
			ValueType = "String"
            ValueData = $startValue
            DependsOn = "[Registry]SetDesktopShortcuts" 
        }

        Registry ZoneMap
        {
            Ensure = "Present"
            Key = $zoneMapPath
            ValueName = $zoneMapName
			ValueType = "Dword"
            ValueData = $zoneMapValue
            DependsOn = "[Registry]SetStartShortcuts" 
        }

        Registry ZoneSecurity
        {
            Ensure = "Present"
            Key = $zoneSecurityPath
            ValueName = $zoneSecurityName
			ValueType = "Dword"
            ValueData = $zoneSecurityValue
            DependsOn = "[Registry]ZoneMap" 
        }

        Script RdGrace
        {
            SetScript = { 
                if(Test-Path $using:gracePath)
                {
                    Remove-ItemProperty -Path $using:gracePath -Name *
                }
            }
            TestScript = { 
                if(Test-Path $using:gracePath)
                {
                    $item = Get-Item -Path $using:gracePath
                    return $item.Property.Count -eq 0
                }

                return $true
            }
            GetScript = { 
                return @{ Key = $using:gracePath }
            }          
            DependsOn = "[Registry]ZoneSecurity" 
        }

		Citrix_MarketplaceConditionWait DomainCondition 
        { 
            Condition = "Domain"
			Machine = $DomainControllerIp
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[Script]RdGrace" 
        }  

		Script ResetAdapter
        { 
			GetScript = { @{} }
			SetScript = { Start-Sleep -Seconds 600; ipconfig /release; ipconfig /renew; ipconfig /flushdns; }
			TestScript = { $false }
            DependsOn = "[Citrix_MarketplaceConditionWait]DomainCondition" 
        }  

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[Script]ResetAdapter" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

		Citrix_MarketplaceConditionWait ControllerCondition 
        { 
            Condition = "Controller"
			Machine = $DeliveryController
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[xComputer]DomainJoin" 
        }  

        Citrix_XenDesktopVDI VDICatalog
        {
            XenDesktopController = $DeliveryController
            CatalogName = "Administrative Desktop"
            DeliveryGroupName = "Administrative Desktop"
            PSDscRunAsCredential = $DomainCreds
            Users = @($DomainCreds.UserName)
            PublishedApplications = $PublishedApplications
			StoreFrontUrl = $StoreFrontUrl
            DependsOn = "[Citrix_MarketplaceConditionWait]ControllerCondition" 
        }

		Citrix_XenDesktopStudioController StudioSetup
        {
			XenDesktopController = $DeliveryController
			StudioMsc = $studioMsc
            DependsOn = "[Citrix_XenDesktopVDI]VDICatalog" 
        }

		Citrix_MarketplaceStatus Status
        {
            DeploymentFQDN = $DeploymentFQDN
            GatewayFQDN = $GatewayFQDN
			MachineName = $env:COMPUTERNAME
			Status = "Succeeded"
            DependsOn = "[Citrix_XenDesktopStudioController]StudioSetup" 
        }
    }
} 
